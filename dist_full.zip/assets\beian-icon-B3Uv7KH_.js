const i="/filing/beian-icon.png";export{i as _};
